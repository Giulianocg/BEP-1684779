
$ python3 ./Things_to_run_Giuliano.py -1 1 0 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 2 0 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 3 0 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 4 0 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 0 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 6 0 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 7 0 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 8 0 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 9 0 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 10 0 'simple' 3

$ python3 ./Things_to_run_Giuliano.py -1 5 20 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 20 'complex' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 40 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 40 'complex' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 60 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 60 'complex' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 80 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 80 'complex' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 100 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 100 'complex' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 120 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 120 'complex' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 140 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 140 'complex' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 160 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 160 'complex' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 180 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 180 'complex' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 200 'simple' 3
$ python3 ./Things_to_run_Giuliano.py -1 5 200 'complex' 3

$ python3 ./Things_to_run_Giuliano.py 55 5 0 'simple' 0
$ python3 ./Things_to_run_Giuliano.py 60 5 0 'simple' 0
$ python3 ./Things_to_run_Giuliano.py 70 5 0 'simple' 0
$ python3 ./Things_to_run_Giuliano.py 80 5 0 'simple' 0
$ python3 ./Things_to_run_Giuliano.py 90 5 0 'simple' 0
$ python3 ./Things_to_run_Giuliano.py 100 5 0 'simple' 0

